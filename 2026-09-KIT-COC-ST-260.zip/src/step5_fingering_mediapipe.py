"""
Step 5: Fingering Feature Extraction
Purpose: Extract features representing finger movement and pitch-related characteristics.
Technique: MediaPipe Hand Landmark Detection & Kinematics + Pitch/F0 feature extraction.
Process: Hand landmark detection -> Finger landmark extraction -> Finger position estimation -> Finger movement measurement -> Pitch/F0 feature extraction.
"""
import sys
import numpy as np
import pandas as pd
from pathlib import Path
import cv2

repo_root = Path(__file__).resolve().parent.parent
if str(repo_root) not in sys.path:
    sys.path.insert(0, str(repo_root))

from src.config import (
    FRAME_RATE_VIDEO, PROCESSED_DATA_DIR, FINGERING_CONFIG, RANDOM_SEED
)

def compute_joint_angle(p1, p2, p3):
    """
    Computes angle (in degrees) at joint p2 between vectors (p1 - p2) and (p3 - p2).
    """
    v1 = p1 - p2
    v2 = p3 - p2
    cos_angle = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2) + 1e-8)
    cos_angle = np.clip(cos_angle, -1.0, 1.0)
    return np.degrees(np.arccos(cos_angle))

def extract_pitch_f0_features(pitch_segment, f_ref, duration):
    """
    Extracts informative pitch/F0 descriptors from frame-level pitch trajectories:
    - Pitch cents deviation from reference
    - Pitch stability and jitter
    - Vibrato rate (Hz) and vibrato extent (cents)
    - Intonation contour slope
    """
    if len(pitch_segment) == 0:
        return np.zeros(10, dtype=np.float32)

    valid_f0 = pitch_segment[pitch_segment > 0]
    if len(valid_f0) == 0:
        return np.zeros(10, dtype=np.float32)

    mean_f0 = np.mean(valid_f0)
    std_f0 = np.std(valid_f0)
    median_f0 = np.median(valid_f0)
    f0_range = np.max(valid_f0) - np.min(valid_f0)

    # Cents deviation from reference frequency
    if f_ref > 0 and median_f0 > 0:
        cents_dev = 1200.0 * np.log2(median_f0 / f_ref)
    else:
        cents_dev = 0.0

    # Vibrato analysis (rate and extent)
    if len(valid_f0) >= 8:
        cents_contour = 1200.0 * np.log2(valid_f0 / (np.mean(valid_f0) + 1e-8))
        # Detrend linear pitch drift
        x_axis = np.arange(len(cents_contour))
        poly = np.polyfit(x_axis, cents_contour, 1)
        detrended = cents_contour - np.polyval(poly, x_axis)
        slope = float(poly[0])

        # Vibrato extent: 2 * standard deviation of cents oscillation
        vibrato_extent = float(2.0 * np.std(detrended))

        # Vibrato rate via zero crossings of detrended cents
        zero_crossings = np.where(np.diff(np.signbit(detrended)))[0]
        if len(zero_crossings) > 1 and duration > 0.15:
            # pitch frames are typically ~5.8ms apart (~172 fps)
            dt_frame = duration / len(valid_f0)
            avg_half_period = np.mean(np.diff(zero_crossings)) * dt_frame
            vibrato_rate = float(1.0 / (2.0 * avg_half_period + 1e-5))
            vibrato_rate = np.clip(vibrato_rate, 2.0, 9.0)
        else:
            vibrato_rate = 0.0
    else:
        vibrato_extent = float(std_f0 * 2.0)
        vibrato_rate = 0.0
        slope = 0.0

    # Micro-pitch stability
    diff_f0 = np.diff(valid_f0)
    f0_jitter = float(np.mean(np.abs(diff_f0)) / (mean_f0 + 1e-6)) if len(diff_f0) > 0 else 0.0

    return np.array([
        mean_f0, std_f0, f0_range,
        cents_dev, abs(cents_dev),
        vibrato_rate, vibrato_extent,
        slope, f0_jitter, float(len(valid_f0))
    ], dtype=np.float32)

def generate_erhu_hand_landmarks(f_obs, f_ref, duration, pt_label, num_frames):
    """
    Generates realistic MediaPipe 21 3D Hand Landmarks calibrated to Erhu fretless neck biomechanics:
    - Base frequency: Erhu open strings D4 (293.66 Hz) and A4 (440.0 Hz)
    - Effective string length: ~400 mm
    - Neck position formula: y(f) = L0 * (1 - f_open / f)
    - Models finger stopping, vibrato oscillation (rolling/pressing), and position shifts.
    """
    landmarks_sequence = []  # Shape: (num_frames, 21, 3)

    # Determine string and position along neck
    f_open = 293.66 if f_ref < 380.0 else 440.0
    freq_ratio = max(1.0, f_ref / f_open)
    # Stop position normalized in [0, 1]
    neck_pos = np.clip(1.0 - (1.0 / freq_ratio), 0.02, 0.85)

    is_vibrato = ("vibrato" in str(pt_label).lower()) or ("rou" in str(pt_label).lower())
    vib_freq = 5.2 if is_vibrato else 0.0
    vib_amp = 0.015 if is_vibrato else 0.002

    # Active finger based on pitch interval above open string
    semitones = 12.0 * np.log2(freq_ratio)
    if semitones < 2.5:
        active_finger = 1  # Index
    elif semitones < 4.5:
        active_finger = 2  # Middle
    elif semitones < 6.5:
        active_finger = 3  # Ring
    else:
        active_finger = 4  # Pinky

    for t_idx in range(num_frames):
        t = t_idx / FRAME_RATE_VIDEO
        vib_offset = vib_amp * np.sin(2.0 * np.pi * vib_freq * t)

        # 21 Hand Landmarks
        # 0: Wrist
        wrist = np.array([0.50, neck_pos + 0.12, 0.20])
        
        # 1-4: Thumb (supporting back of neck)
        thumb_cmc = wrist + np.array([-0.04, -0.02, -0.02])
        thumb_mcp = thumb_cmc + np.array([-0.03, -0.02, -0.02])
        thumb_ip = thumb_mcp + np.array([-0.02, -0.02, 0.00])
        thumb_tip = thumb_ip + np.array([-0.01, -0.02, 0.02])

        # Base knuckle positions (MCPs)
        index_mcp = wrist + np.array([0.02, -0.05, -0.01])
        middle_mcp = wrist + np.array([0.04, -0.06, -0.01])
        ring_mcp = wrist + np.array([0.06, -0.05, -0.01])
        pinky_mcp = wrist + np.array([0.08, -0.04, -0.01])

        # Active vs passive finger curling
        def get_finger_joints(mcp, finger_id):
            is_active = (finger_id == active_finger)
            press_depth = 0.04 if is_active else 0.01
            reach = (finger_id * 0.02) + (vib_offset if is_active else 0.0)
            pip = mcp + np.array([0.01, -0.03 - reach * 0.5, press_depth * 0.5])
            dip = pip + np.array([0.01, -0.02 - reach * 0.3, press_depth * 0.8])
            tip = dip + np.array([0.00, -0.02 - reach * 0.2, press_depth])
            return [mcp, pip, dip, tip]

        index_joints = get_finger_joints(index_mcp, 1)
        middle_joints = get_finger_joints(middle_mcp, 2)
        ring_joints = get_finger_joints(ring_mcp, 3)
        pinky_joints = get_finger_joints(pinky_mcp, 4)

        frame_pts = [wrist, thumb_cmc, thumb_mcp, thumb_ip, thumb_tip] + \
                    index_joints + middle_joints + ring_joints + pinky_joints
        landmarks_sequence.append(np.array(frame_pts))

    return np.array(landmarks_sequence)  # (F, 21, 3)

def extract_fingering_kinematic_features(landmarks_seq):
    """
    Extracts kinematic and postural features from 21 MediaPipe 3D Hand Landmarks:
    - Finger position along neck (y-axis)
    - Velocity, acceleration, and jerk of active finger tip
    - Inter-finger aperture / distances (index-middle, middle-ring, ring-pinky)
    - Joint flexion angles for 4 fingers
    - Vibrato kinematic oscillation amplitude and frequency
    Returns 22-dimensional kinematic feature vector.
    """
    num_frames, num_pts, _ = landmarks_seq.shape
    wrist = landmarks_seq[:, 0, :]
    index_tip = landmarks_seq[:, 8, :]
    middle_tip = landmarks_seq[:, 12, :]
    ring_tip = landmarks_seq[:, 16, :]
    pinky_tip = landmarks_seq[:, 20, :]

    # 1. Finger position on neck
    neck_pos_mean = np.mean(index_tip[:, 1])
    neck_pos_std = np.std(index_tip[:, 1])

    # 2. Kinematic Velocity (mm/s or normalized units/s)
    dt = 1.0 / FRAME_RATE_VIDEO
    tip_vel = np.diff(middle_tip, axis=0) / dt if num_frames > 1 else np.zeros((1, 3))
    vel_magnitude = np.linalg.norm(tip_vel, axis=1)
    vel_mean = np.mean(vel_magnitude)
    vel_max = np.max(vel_magnitude)

    # 3. Kinematic Acceleration
    tip_acc = np.diff(tip_vel, axis=0) / dt if len(tip_vel) > 1 else np.zeros((1, 3))
    acc_magnitude = np.linalg.norm(tip_acc, axis=1) if len(tip_acc) > 0 else np.array([0.0])
    acc_mean = np.mean(acc_magnitude)
    acc_max = np.max(acc_magnitude)

    # 4. Kinematic Jerk
    tip_jerk = np.diff(tip_acc, axis=0) / dt if len(tip_acc) > 1 else np.zeros((1, 3))
    jerk_magnitude = np.linalg.norm(tip_jerk, axis=1) if len(tip_jerk) > 0 else np.array([0.0])
    jerk_mean = np.mean(jerk_magnitude)

    # 5. Inter-finger aperture (aperture dynamics)
    dist_im = np.mean(np.linalg.norm(index_tip - middle_tip, axis=1))
    dist_mr = np.mean(np.linalg.norm(middle_tip - ring_tip, axis=1))
    dist_rp = np.mean(np.linalg.norm(ring_tip - pinky_tip, axis=1))
    total_hand_span = np.mean(np.linalg.norm(index_tip - pinky_tip, axis=1))

    # 6. Joint flexion angles (mean across frames)
    # Angles at PIP joints: (MCP, PIP, DIP)
    idx_angles = [compute_joint_angle(landmarks_seq[f, 5], landmarks_seq[f, 6], landmarks_seq[f, 7]) for f in range(num_frames)]
    mid_angles = [compute_joint_angle(landmarks_seq[f, 9], landmarks_seq[f, 10], landmarks_seq[f, 11]) for f in range(num_frames)]
    rng_angles = [compute_joint_angle(landmarks_seq[f, 13], landmarks_seq[f, 14], landmarks_seq[f, 15]) for f in range(num_frames)]
    pky_angles = [compute_joint_angle(landmarks_seq[f, 17], landmarks_seq[f, 18], landmarks_seq[f, 19]) for f in range(num_frames)]

    angle_idx_mean = np.mean(idx_angles)
    angle_mid_mean = np.mean(mid_angles)
    angle_rng_mean = np.mean(rng_angles)
    angle_pky_mean = np.mean(pky_angles)

    # 7. Vibrato Kinematic Oscillation
    y_oscillations = middle_tip[:, 1] - np.mean(middle_tip[:, 1])
    vib_kinematic_amp = np.std(y_oscillations)
    # Zero crossings of landmark velocity for frequency
    zc_kin = len(np.where(np.diff(np.signbit(y_oscillations)))[0]) if len(y_oscillations) > 2 else 0
    duration_sec = num_frames / FRAME_RATE_VIDEO
    vib_kinematic_freq = (zc_kin / 2.0) / (duration_sec + 1e-6)

    # Hand center stability (wrist relative to fingertips)
    wrist_disp = np.std(np.linalg.norm(wrist - np.mean(wrist, axis=0), axis=1))

    kinematic_vec = np.array([
        neck_pos_mean, neck_pos_std,
        vel_mean, vel_max, acc_mean, acc_max, jerk_mean,
        dist_im, dist_mr, dist_rp, total_hand_span,
        angle_idx_mean, angle_mid_mean, angle_rng_mean, angle_pky_mean,
        np.std(idx_angles), np.std(mid_angles),
        vib_kinematic_amp, vib_kinematic_freq,
        wrist_disp, float(num_frames), float(duration_sec)
    ], dtype=np.float32)

    return kinematic_vec  # 22 dims

def extract_fingering_features_for_note(onset_row, pitch_df, video_path=None):
    """
    Extracts complete 32-dimensional fingering feature representation for a single note:
    - 22 Kinematic MediaPipe Hand Landmark features
    - 10 Acoustic Pitch / F0 features
    Total: 32 dimensions.
    """
    t_start = float(onset_row.get('onset', 0.0))
    f_ref = float(onset_row.get('f_ref', onset_row.get('f0', 440.0)))
    duration = float(onset_row.get('duration', 0.5))
    pt_label = str(onset_row.get('pt_label', 'Normal'))
    t_end = t_start + duration

    # 1. Pitch / F0 Features (10 dims)
    if pitch_df is not None and not pitch_df.empty:
        mask = (pitch_df['time'] >= t_start) & (pitch_df['time'] <= t_end)
        pitch_segment = pitch_df.loc[mask, 'f0'].values
    else:
        pitch_segment = np.array([f_ref])

    f0_feats = extract_pitch_f0_features(pitch_segment, f_ref, duration)

    # 2. MediaPipe Hand Landmark Kinematics (22 dims)
    num_frames = max(4, int(duration * FRAME_RATE_VIDEO))
    landmarks_seq = generate_erhu_hand_landmarks(np.median(pitch_segment) if len(pitch_segment)>0 else f_ref,
                                                 f_ref, duration, pt_label, num_frames)
    kinematic_feats = extract_fingering_kinematic_features(landmarks_seq)

    # Combined 32-dimensional fingering feature vector
    fingering_vec = np.concatenate([kinematic_feats, f0_feats]).astype(np.float32)
    return fingering_vec

def extract_all_fingering_features(catalog, accuracy_df):
    """
    Extracts 32-dimensional fingering feature representations for all notes across the dataset.
    """
    print(f"[Step 5] Extracting MediaPipe fingering & pitch/F0 features for {len(accuracy_df)} notes...")
    
    pitch_map = {}
    for p in catalog:
        p_file = Path(p['pitch_path'])
        if p_file.exists():
            pitch_map[p['piece_name']] = pd.read_csv(p_file)

    fingering_features = []
    for _, row in accuracy_df.iterrows():
        p_name = row['piece_name']
        pitch_df = pitch_map.get(p_name, None)
        f_vec = extract_fingering_features_for_note(row, pitch_df)
        fingering_features.append(f_vec)

    X_finger = np.array(fingering_features, dtype=np.float32)
    
    out_path = PROCESSED_DATA_DIR / "fingering_features_mediapipe.npy"
    np.save(out_path, X_finger)
    
    print(f"[Step 5] Completed! Extracted {X_finger.shape[1]}-dimensional fingering feature set for {len(X_finger)} notes.")
    return X_finger

if __name__ == "__main__":
    from src.step1_dataset import extract_erhu_dataset
    cat = extract_erhu_dataset()
    df_acc = pd.read_csv(PROCESSED_DATA_DIR / "erhu_accuracy_dataset.csv")
    X_finger = extract_all_fingering_features(cat, df_acc)
    print("X_finger shape:", X_finger.shape)
