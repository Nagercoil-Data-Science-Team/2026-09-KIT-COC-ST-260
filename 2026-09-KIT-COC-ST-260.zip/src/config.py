"""
Configuration module for IMGO-TabPFN framework.
Defines directories, hyperparameters, scoring criteria, and model settings.
"""
import os
from pathlib import Path

# Base Paths
BASE_DIR = Path(r"d:\Alan christo\september2026\2026-09-KIT-COC-ST-260")
ZIP_PATH = BASE_DIR / "CCOM-HuQin-v2.0.1-audios.zip"
DATA_DIR = BASE_DIR / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"
RESULTS_DIR = BASE_DIR / "results"
FIGURES_DIR = RESULTS_DIR / "figures"
TABLES_DIR = RESULTS_DIR / "tables"

for d in [DATA_DIR, RAW_DATA_DIR, PROCESSED_DATA_DIR, RESULTS_DIR, FIGURES_DIR, TABLES_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# Audio Parameters
SAMPLE_RATE = 22050
N_FFT = 1024
HOP_LENGTH = 512
N_MELS = 64
FRAME_RATE_VIDEO = 30.0  # fps for video/landmark alignment

# Reference-Based Accuracy Scoring Criteria
TAU_HIGH = 81.0
TAU_MEDIUM = 73.0
WEIGHT_BOWING = 0.50
WEIGHT_FINGERING = 0.50

# Pitch Tolerance (cents)
INTONATION_TOLERANCE_CENTS = 50.0  # 50 cents (quarter tone) benchmark
ONSET_TOLERANCE_SEC = 0.05        # 50 ms onset timing window

# Deep Sparse Autoencoder (DSAE) Parameters
DSAE_CONFIG = {
    "hidden_layers": [128, 64, 32],
    "latent_dim": 32,
    "sparsity_param_rho": 0.05,
    "sparsity_weight_beta": 1.0,
    "weight_decay": 1e-4,
    "learning_rate": 0.002,
    "epochs": 40,
    "batch_size": 64,
}

# MediaPipe Hand & Fingering Kinematics
FINGERING_CONFIG = {
    "num_landmarks": 21,
    "dim_coords": 3,
    "neck_length_mm": 400.0,
    "erhu_strings": ["D4 (293.66 Hz)", "A4 (440.0 Hz)"],
}

# Improved Moss Growth Optimization (IMGO) Parameters
IMGO_CONFIG = {
    "pop_size": 30,
    "max_iter": 50,
    "w_max": 0.9,       # Initial moisture inertia weight
    "w_min": 0.2,       # Final moisture inertia weight
    "levy_beta": 1.5,   # Levy flight parameter
    "mutation_rate": 0.10,
    "crossover_rate": 0.80,
    "alpha": 0.95,      # Multi-objective balance: 0.95 accuracy + 0.05 sparsity
    "seed": 42
}

# Classification & Evaluation Settings
RANDOM_SEED = 42
TEST_SIZE = 0.20
VAL_SIZE = 0.15
CLASS_NAMES = ["Low Accuracy", "Medium Accuracy", "High Accuracy"]
CLASS_LABELS = [0, 1, 2]

# Baseline Models to Benchmark
BASELINE_MODELS = [
    "SVM",
    "Random Forest",
    "KNN",
    "Decision Tree",
    "XGBoost",
    "TabPFN-2.5",
    "Proposed IMGO-TabPFN"
]
