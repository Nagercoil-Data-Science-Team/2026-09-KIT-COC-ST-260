"""
Step 4: Bowing Feature Extraction
Purpose: Extract informative features representing bowing-related characteristics from preprocessed performance data.
Technique: Deep Sparse Autoencoder (DSAE)
Process: Feature encoding -> Sparse representation learning -> Latent feature extraction.
"""
import sys
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import librosa
from pathlib import Path

repo_root = Path(__file__).resolve().parent.parent
if str(repo_root) not in sys.path:
    sys.path.insert(0, str(repo_root))

from src.config import (
    SAMPLE_RATE, DSAE_CONFIG, PROCESSED_DATA_DIR, RANDOM_SEED
)
from src.step3_preprocessing import preprocess_piece_audio, extract_note_segment

# PyTorch Deep Sparse Autoencoder Architecture
class DeepSparseAutoencoder(nn.Module):
    def __init__(self, input_dim=76, latent_dim=32):
        super(DeepSparseAutoencoder, self).__init__()
        # Encoder
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Linear(64, latent_dim),
            nn.Sigmoid()  # Sigmoid output in [0, 1] for KL-divergence sparsity
        )
        # Decoder
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Linear(64, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Linear(128, input_dim)
        )

    def forward(self, x):
        latent = self.encoder(x)
        reconstruction = self.decoder(latent)
        return reconstruction, latent

    def encode(self, x):
        with torch.no_grad():
            return self.encoder(x)

def kl_divergence(rho, rho_hat):
    """
    Computes Kullback-Leibler (KL) divergence between desired sparsity rho and average activation rho_hat.
    KL(rho || rho_hat) = rho * log(rho / rho_hat) + (1 - rho) * log((1 - rho) / (1 - rho_hat))
    """
    rho_hat = torch.clamp(rho_hat, 1e-5, 1.0 - 1e-5)
    return rho * torch.log(rho / rho_hat) + (1.0 - rho) * torch.log((1.0 - rho) / (1.0 - rho_hat))

def extract_raw_bowing_descriptors(note_audio, sr=SAMPLE_RATE):
    """
    Extracts 76-dimensional acoustic/spectral bowing descriptors from a note audio segment.
    """
    if len(note_audio) < 512:
        note_audio = np.pad(note_audio, (0, 512 - len(note_audio)))

    # 1. Mel Spectrogram (32 bands)
    mel_spec = librosa.feature.melspectrogram(y=note_audio, sr=sr, n_fft=512, hop_length=256, n_mels=32)
    log_mel = librosa.power_to_db(mel_spec + 1e-6)
    mel_mean = np.mean(log_mel, axis=1)  # 32
    mel_std = np.std(log_mel, axis=1)    # 32

    # 2. Spectral Features
    cent = librosa.feature.spectral_centroid(y=note_audio, sr=sr, n_fft=512, hop_length=256)
    cent_mean, cent_std = np.mean(cent), np.std(cent)  # 2

    rolloff = librosa.feature.spectral_rolloff(y=note_audio, sr=sr, n_fft=512, hop_length=256)
    roll_mean, roll_std = np.mean(rolloff), np.std(rolloff)  # 2

    flatness = librosa.feature.spectral_flatness(y=note_audio, n_fft=512, hop_length=256)
    flat_mean, flat_std = np.mean(flatness), np.std(flatness)  # 2

    # 3. Temporal / Dynamic Bowing Features
    zcr = librosa.feature.zero_crossing_rate(note_audio, hop_length=256)
    zcr_mean, zcr_std = np.mean(zcr), np.std(zcr)  # 2

    rms = librosa.feature.rms(y=note_audio, hop_length=256)[0]
    rms_mean, rms_std = np.mean(rms), np.std(rms)  # 2

    # Envelope Attack & Decay Dynamics
    peak_idx = np.argmax(rms) if len(rms) > 0 else 0
    attack_time = float(peak_idx * 256 / sr)
    attack_slope = float(rms[peak_idx] / (attack_time + 1e-4)) if len(rms) > 0 else 0.0

    decay_time = float((len(rms) - 1 - peak_idx) * 256 / sr)
    decay_slope = float(rms[peak_idx] / (decay_time + 1e-4)) if len(rms) > 0 else 0.0  # 4

    features = np.concatenate([
        mel_mean, mel_std,
        [cent_mean, cent_std, roll_mean, roll_std, flat_mean, flat_std],
        [zcr_mean, zcr_std, rms_mean, rms_std],
        [attack_time, attack_slope, decay_time, decay_slope]
    ])
    return features.astype(np.float32)

def extract_all_raw_bowing_features(catalog, accuracy_df):
    """
    Extracts raw bowing descriptors for all notes across the catalog.
    """
    print(f"[Step 4] Extracting raw bowing descriptors for {len(accuracy_df)} notes...")
    raw_features_list = []
    
    # Group by piece for efficient audio caching
    grouped = accuracy_df.groupby('piece_name')
    piece_map = {p['piece_name']: p for p in catalog}

    for piece_name, group in grouped:
        if piece_name not in piece_map:
            continue
        p_info = piece_map[piece_name]
        audio, sr = preprocess_piece_audio(p_info['audio_path'])

        for _, row in group.iterrows():
            onset = row['onset']
            duration = row['duration']
            seg = extract_note_segment(audio, sr, onset, duration)
            feat = extract_raw_bowing_descriptors(seg, sr)
            raw_features_list.append((row['piece_name'], row['note_idx'], feat))

    # Match ordering with accuracy_df
    feat_dict = {(p, idx): f for p, idx, f in raw_features_list}
    ordered_features = []
    for _, row in accuracy_df.iterrows():
        key = (row['piece_name'], row['note_idx'])
        if key in feat_dict:
            ordered_features.append(feat_dict[key])
        else:
            ordered_features.append(np.zeros(76, dtype=np.float32))

    X_raw = np.array(ordered_features, dtype=np.float32)
    return X_raw

def train_dsae(X_raw, config=DSAE_CONFIG):
    """
    Trains Deep Sparse Autoencoder on raw bowing features.
    Enforces KL-divergence sparsity penalty on latent representations.
    """
    torch.manual_seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)
    
    input_dim = X_raw.shape[1]
    latent_dim = config["latent_dim"]
    rho = config["sparsity_param_rho"]
    beta = config["sparsity_weight_beta"]
    epochs = config["epochs"]
    batch_size = config["batch_size"]
    lr = config["learning_rate"]
    
    # Feature Standardization
    mean = np.mean(X_raw, axis=0, keepdims=True)
    std = np.std(X_raw, axis=0, keepdims=True) + 1e-6
    X_norm = (X_raw - mean) / std

    dataset = TensorDataset(torch.from_numpy(X_norm))
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    model = DeepSparseAutoencoder(input_dim=input_dim, latent_dim=latent_dim)
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=config["weight_decay"])
    mse_criterion = nn.MSELoss()

    model.train()
    print(f"[Step 4] Training Deep Sparse Autoencoder (DSAE): Input={input_dim} -> Latent={latent_dim} (epochs={epochs})...")
    
    epoch_losses = []
    for epoch in range(1, epochs + 1):
        total_loss = 0.0
        total_mse = 0.0
        total_kl = 0.0
        
        for batch in loader:
            x_b = batch[0]
            optimizer.zero_grad()
            recon, latent = model(x_b)
            
            # Reconstruction Loss (MSE)
            loss_mse = mse_criterion(recon, x_b)
            
            # Sparsity Loss (KL Divergence on latent bottleneck)
            rho_hat = torch.mean(latent, dim=0)
            loss_kl = torch.sum(kl_divergence(rho, rho_hat))
            
            loss = loss_mse + beta * loss_kl
            loss.backward()
            optimizer.step()

            total_loss += loss.item() * len(x_b)
            total_mse += loss_mse.item() * len(x_b)
            total_kl += loss_kl.item() * len(x_b)

        avg_loss = total_loss / len(X_norm)
        avg_mse = total_mse / len(X_norm)
        avg_kl = total_kl / len(X_norm)
        epoch_losses.append(avg_loss)

        if epoch % 10 == 0 or epoch == epochs:
            print(f"  Epoch {epoch:2d}/{epochs:2d} - Total Loss: {avg_loss:.4f} (MSE: {avg_mse:.4f}, KL Sparsity: {avg_kl:.4f})")

    # Extract Latent Bowing Representations
    model.eval()
    with torch.no_grad():
        _, latent_features = model(torch.from_numpy(X_norm))
        Z_bow = latent_features.numpy()

    # Save model checkpoint and features
    out_feat_path = PROCESSED_DATA_DIR / "bowing_features_dsae.npy"
    out_raw_path = PROCESSED_DATA_DIR / "bowing_features_raw.npy"
    np.save(out_feat_path, Z_bow)
    np.save(out_raw_path, X_raw)
    
    print(f"[Step 4] DSAE training completed! Extracted {Z_bow.shape[1]}-dimensional deep bowing features for {len(Z_bow)} notes.")
    return Z_bow, X_raw, model, epoch_losses

if __name__ == "__main__":
    from src.step1_dataset import extract_erhu_dataset
    cat = extract_erhu_dataset()
    df_acc = pd.read_csv(PROCESSED_DATA_DIR / "erhu_accuracy_dataset.csv")
    X_raw = extract_all_raw_bowing_features(cat, df_acc)
    Z_bow, _, _, _ = train_dsae(X_raw)
    print("Z_bow shape:", Z_bow.shape)
