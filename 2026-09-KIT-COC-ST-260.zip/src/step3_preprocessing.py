"""
Step 3: Audio and Performance Preprocessing
Performs:
- Noise reduction (spectral gating / filtering)
- Audio loudness / RMS normalization
- Video frame preprocessing & temporal framing
- Audio-video synchronization
- Note-level segmentation
"""
import sys
import numpy as np
import scipy.signal as signal
import soundfile as sf
import librosa
from pathlib import Path

repo_root = Path(__file__).resolve().parent.parent
if str(repo_root) not in sys.path:
    sys.path.insert(0, str(repo_root))

from src.config import SAMPLE_RATE, FRAME_RATE_VIDEO, PROCESSED_DATA_DIR

def denoise_audio(audio_signal, sr=SAMPLE_RATE, noise_threshold=0.015):
    """
    Applies spectral noise reduction using soft spectral gating and high-pass filtering.
    Filters low-frequency mechanical rumble below 80 Hz (Erhu lowest string D4 is ~293 Hz).
    """
    # 1. High-pass filter above 100 Hz to remove hum/sub-rumble
    b, a = signal.butter(4, 100.0 / (sr / 2.0), btype='highpass')
    filtered = signal.filtfilt(b, a, audio_signal)

    # 2. Spectral magnitude thresholding (soft spectral gating)
    stft = librosa.stft(filtered, n_fft=1024, hop_length=512)
    mag, phase = np.abs(stft), np.angle(stft)

    # Estimate noise floor from the lowest 10% magnitude frames
    noise_est = np.percentile(mag, 10, axis=1, keepdims=True)
    gain = np.maximum(0.0, 1.0 - (noise_threshold * noise_est) / (mag + 1e-8))
    denoised_mag = mag * gain

    denoised_audio = librosa.istft(denoised_mag * np.exp(1j * phase), hop_length=512)
    return denoised_audio.astype(np.float32)

def normalize_audio(audio_signal, target_rms=0.10, peak_limit=0.95):
    """
    Normalizes audio loudness via RMS scaling with soft peak limiting.
    """
    rms = np.sqrt(np.mean(audio_signal**2) + 1e-9)
    if rms > 0:
        scaled = audio_signal * (target_rms / rms)
    else:
        scaled = audio_signal

    # Soft peak limiting
    peak = np.max(np.abs(scaled))
    if peak > peak_limit:
        scaled = scaled * (peak_limit / peak)

    return scaled.astype(np.float32)

def extract_note_segment(audio, sr, onset_sec, duration_sec, pad_sec=0.03):
    """
    Extracts a synchronized note audio segment with a small context window.
    """
    start_sample = max(0, int((onset_sec - pad_sec) * sr))
    end_sample = min(len(audio), int((onset_sec + duration_sec + pad_sec) * sr))
    segment = audio[start_sample:end_sample]
    
    # Ensure minimum length for analysis
    if len(segment) < 1024:
        segment = np.pad(segment, (0, 1024 - len(segment)))
    return segment

def compute_av_sync_frames(onset_sec, duration_sec, fps=FRAME_RATE_VIDEO):
    """
    Computes synchronized video frame indices for note-level temporal analysis.
    """
    start_frame = max(0, int(onset_sec * fps))
    num_frames = max(3, int(duration_sec * fps))
    frame_indices = np.arange(start_frame, start_frame + num_frames)
    frame_timestamps = frame_indices / fps
    return frame_indices, frame_timestamps

def preprocess_piece_audio(audio_path, target_sr=SAMPLE_RATE):
    """
    Loads, resamples, denoises, and normalizes a piece audio file using fast soundfile I/O.
    """
    audio, sr = sf.read(audio_path, dtype='float32')
    if len(audio.shape) > 1:
        audio = np.mean(audio, axis=1)

    if sr != target_sr:
        from math import gcd
        g = gcd(int(target_sr), int(sr))
        up = int(target_sr) // g
        down = int(sr) // g
        audio = signal.resample_poly(audio, up, down).astype(np.float32)
        sr = target_sr

    denoised = denoise_audio(audio, sr=sr)
    normalized = normalize_audio(denoised)
    return normalized, sr

if __name__ == "__main__":
    from src.step1_dataset import extract_erhu_dataset
    cat = extract_erhu_dataset()
    sample_piece = cat[0]
    print(f"Testing preprocessing on: {sample_piece['piece_name']}")
    audio, sr = preprocess_piece_audio(sample_piece['audio_path'])
    print(f"Preprocessed audio shape: {audio.shape}, Duration: {len(audio)/sr:.2f}s")
    note_seg = extract_note_segment(audio, sr, onset_sec=1.0, duration_sec=0.5)
    print(f"Sample note segment length: {len(note_seg)} samples")
