"""
IMGO-TabPFN: Machine Learning-Based Evaluation of Bowing and Fingering Accuracy in Erhu Performance
Package Initialization
"""
__version__ = "1.0.0"
