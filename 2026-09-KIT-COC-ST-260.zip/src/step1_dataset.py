"""
Step 1: Dataset Acquisition and Preparation
Extracts, parses, and validates the Erhu multimodal performance data from CCOM-HuQin-v2.0.1-audios.zip.
"""
import os
import sys
import json
import zipfile
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
warnings.filterwarnings("ignore")

# Ensure repository root is in python path
repo_root = Path(__file__).resolve().parent.parent
if str(repo_root) not in sys.path:
    sys.path.insert(0, str(repo_root))

from src.config import ZIP_PATH, RAW_DATA_DIR, PROCESSED_DATA_DIR, SAMPLE_RATE

def extract_erhu_dataset(force_extract=False):
    """
    Extracts Erhu excerpts and metadata from CCOM-HuQin zip file into RAW_DATA_DIR.
    """
    target_dir = RAW_DATA_DIR / "erhu"
    catalog_path = PROCESSED_DATA_DIR / "erhu_catalog.json"
    
    if target_dir.exists() and catalog_path.exists() and not force_extract:
        print(f"[Step 1] Erhu dataset already extracted at {target_dir}. Loading catalog.")
        with open(catalog_path, "r", encoding="utf-8") as f:
            catalog = json.load(f)
        return catalog

    print(f"[Step 1] Opening zip: {ZIP_PATH}")
    if not ZIP_PATH.exists():
        raise FileNotFoundError(f"Dataset zip archive not found at: {ZIP_PATH}")

    target_dir.mkdir(parents=True, exist_ok=True)
    
    with zipfile.ZipFile(ZIP_PATH, 'r') as z:
        # Extract metadata
        metadata_member = "CCOM-HuQin-v2.0.1-audios/metadata-v2.0.csv"
        z.extract(metadata_member, RAW_DATA_DIR)
        
        # Identify all Erhu Excerpt files
        erhu_members = [
            m for m in z.namelist() 
            if "Excerpts/Erhu" in m and not m.endswith('/')
        ]
        print(f"[Step 1] Extracting {len(erhu_members)} Erhu excerpt files to {target_dir}...")
        for m in erhu_members:
            z.extract(m, RAW_DATA_DIR)

    # Reorganize and index the extracted pieces
    extracted_root = RAW_DATA_DIR / "CCOM-HuQin-v2.0.1-audios" / "Excerpts"
    metadata_file = RAW_DATA_DIR / "CCOM-HuQin-v2.0.1-audios" / "metadata-v2.0.csv"
    
    df_meta = pd.read_csv(metadata_file)
    df_erhu_meta = df_meta[df_meta['Instrument'].str.strip() == 'Erhu'].copy()
    
    catalog = []
    
    for player_folder in ["Erhu-1", "Erhu-2", "Erhu-3"]:
        player_path = extracted_root / player_folder
        if not player_path.exists():
            continue
            
        for piece_folder in player_path.iterdir():
            if not piece_folder.is_dir():
                continue
            
            piece_name = piece_folder.name
            audio_file = piece_folder / f"{piece_name}.wav"
            onset_file = piece_folder / f"{piece_name}-onset.csv"
            pitch_file = piece_folder / f"{piece_name}-pitch.csv"
            pt_file = piece_folder / f"{piece_name}-PT.csv"
            xml_file = piece_folder / f"{piece_name}.musicxml"
            pdf_file = piece_folder / f"{piece_name}.pdf"
            
            # Check availability
            has_audio = audio_file.exists()
            has_onset = onset_file.exists()
            has_pitch = pitch_file.exists()
            has_pt = pt_file.exists()
            has_xml = xml_file.exists()
            
            num_onsets = len(pd.read_csv(onset_file)) if has_onset else 0
            num_pitch_frames = len(pd.read_csv(pitch_file)) if has_pitch else 0
            num_pt_marks = len(pd.read_csv(pt_file)) if has_pt else 0
            
            # Match with metadata
            meta_match = df_erhu_meta[df_erhu_meta['Filename (Pinyin)'].str.lower() == piece_name.lower()]
            composer = meta_match['Composers (CH/EN)'].values[0] if not meta_match.empty else "Traditional"
            region = meta_match['Region'].values[0] if not meta_match.empty else "China"
            duration_meta = meta_match['Duration'].values[0] if not meta_match.empty else "N/A"
            
            piece_info = {
                "player": player_folder,
                "piece_name": piece_name,
                "audio_path": str(audio_file),
                "onset_path": str(onset_file),
                "pitch_path": str(pitch_file),
                "pt_path": str(pt_file),
                "xml_path": str(xml_file) if has_xml else None,
                "pdf_path": str(pdf_file) if pdf_file.exists() else None,
                "num_notes": num_onsets,
                "num_pitch_frames": num_pitch_frames,
                "num_pt_marks": num_pt_marks,
                "composer": str(composer),
                "region": str(region),
                "duration_meta": str(duration_meta)
            }
            catalog.append(piece_info)
            
    with open(catalog_path, "w", encoding="utf-8") as f:
        json.dump(catalog, f, indent=2, ensure_ascii=False)
        
    print(f"[Step 1] Completed! Successfully indexed {len(catalog)} Erhu musical excerpts.")
    print(f"Total notes indexed across pieces: {sum(p['num_notes'] for p in catalog)}")
    return catalog

if __name__ == "__main__":
    cat = extract_erhu_dataset()
    print("Catalog summary:")
    for item in cat[:5]:
        print(f" - [{item['player']}] {item['piece_name']}: {item['num_notes']} notes, {item['num_pt_marks']} PTs")
