"""
Step 6: Bowing and Fingering Feature Fusion
Purpose: Combine the extracted bowing and fingering features into a unified feature representation.
Input: Bowing feature representation (DSAE) + Fingering feature set (MediaPipe & Pitch)
Technique: Feature-level concatenation
Process: Feature alignment -> Feature concatenation -> Unified feature vector formation.
"""
import sys
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.preprocessing import StandardScaler

repo_root = Path(__file__).resolve().parent.parent
if str(repo_root) not in sys.path:
    sys.path.insert(0, str(repo_root))

from src.config import PROCESSED_DATA_DIR

def fuse_bowing_and_fingering_features(Z_bow=None, X_finger=None, accuracy_df=None):
    """
    Concatenates 32-dim deep bowing features and 32-dim MediaPipe fingering features.
    Standardizes the unified 64-dimensional feature representation.
    """
    if Z_bow is None:
        bow_path = PROCESSED_DATA_DIR / "bowing_features_dsae.npy"
        if not bow_path.exists():
            raise FileNotFoundError(f"DSAE Bowing features not found at: {bow_path}")
        Z_bow = np.load(bow_path)

    if X_finger is None:
        finger_path = PROCESSED_DATA_DIR / "fingering_features_mediapipe.npy"
        if not finger_path.exists():
            raise FileNotFoundError(f"Fingering features not found at: {finger_path}")
        X_finger = np.load(finger_path)

    if accuracy_df is None:
        acc_path = PROCESSED_DATA_DIR / "erhu_accuracy_dataset.csv"
        accuracy_df = pd.read_csv(acc_path)

    assert len(Z_bow) == len(X_finger) == len(accuracy_df), \
        f"Length mismatch: Bowing={len(Z_bow)}, Fingering={len(X_finger)}, Labels={len(accuracy_df)}"

    print(f"[Step 6] Fusing Bowing features ({Z_bow.shape[1]} dims) and Fingering features ({X_finger.shape[1]} dims)...")
    
    # Feature names
    bow_names = [f"Bowing_DSAE_Dim_{i+1:02d}" for i in range(Z_bow.shape[1])]
    kin_names = [
        "Neck_Position_Mean", "Neck_Position_Std", "Tip_Velocity_Mean", "Tip_Velocity_Max",
        "Tip_Acceleration_Mean", "Tip_Acceleration_Max", "Tip_Jerk_Mean",
        "Dist_Index_Middle", "Dist_Middle_Ring", "Dist_Ring_Pinky", "Total_Hand_Span",
        "Angle_Index_Mean", "Angle_Middle_Mean", "Angle_Ring_Mean", "Angle_Pinky_Mean",
        "Angle_Index_Std", "Angle_Middle_Std", "Vibrato_Kinematic_Amp", "Vibrato_Kinematic_Freq",
        "Wrist_Displacement", "Num_Frames", "Duration_Sec"
    ]
    f0_names = [
        "Pitch_F0_Mean", "Pitch_F0_Std", "Pitch_F0_Range",
        "Pitch_Cents_Deviation", "Abs_Cents_Deviation",
        "Vibrato_Rate_Hz", "Vibrato_Extent_Cents",
        "Intonation_Contour_Slope", "F0_Micro_Jitter", "Valid_Pitch_Frames"
    ]
    finger_names = kin_names + f0_names
    feature_names = bow_names + finger_names

    # Feature-Level Concatenation
    F_unscaled = np.concatenate([Z_bow, X_finger], axis=1)

    # Standardization / Unified Scaling
    scaler = StandardScaler()
    F_scaled = scaler.fit_transform(F_unscaled).astype(np.float32)

    y_labels = accuracy_df['category_label'].values.astype(np.int64)
    y_scores = accuracy_df['s_total'].values.astype(np.float32)

    out_file = PROCESSED_DATA_DIR / "fused_bowing_fingering_features.npz"
    np.savez_compressed(
        out_file,
        X_fused=F_scaled,
        X_unscaled=F_unscaled,
        y=y_labels,
        scores=y_scores,
        feature_names=np.array(feature_names),
        bow_dim=Z_bow.shape[1],
        finger_dim=X_finger.shape[1]
    )

    print(f"[Step 6] Completed! Formed unified feature matrix: shape={F_scaled.shape}")
    print(f"Total features: {len(feature_names)} (Bowing: {len(bow_names)}, Fingering: {len(finger_names)})")
    return F_scaled, y_labels, feature_names

if __name__ == "__main__":
    F_fused, y, names = fuse_bowing_and_fingering_features()
    print("Class label counts:", np.bincount(y))
