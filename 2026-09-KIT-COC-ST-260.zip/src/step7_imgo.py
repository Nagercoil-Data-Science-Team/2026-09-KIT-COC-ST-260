"""
Step 7: Feature Selection Using Improved Moss Growth Optimization (IMGO)
Purpose: Select the most informative features and reduce redundant features from the fused feature matrix.
Technique: Binary Improved Moss Growth Optimization (IMGO)
Process: Binary feature representation -> Fitness evaluation -> IMGO position update -> Feature subset evaluation -> Optimal feature selection.
"""
import sys
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.neighbors import KNeighborsClassifier
from scipy.special import gamma

repo_root = Path(__file__).resolve().parent.parent
if str(repo_root) not in sys.path:
    sys.path.insert(0, str(repo_root))

from src.config import IMGO_CONFIG, PROCESSED_DATA_DIR, RANDOM_SEED

def levy_flight(beta, dim):
    """
    Generates Levy flight step vector based on Mantegna's algorithm.
    """
    sigma_u = (gamma(1 + beta) * np.sin(np.pi * beta / 2.0) / 
               (gamma((1 + beta) / 2.0) * beta * (2 ** ((beta - 1) / 2.0)))) ** (1.0 / beta)
    u = np.random.normal(0, sigma_u, size=dim)
    v = np.random.normal(0, 1.0, size=dim)
    step = u / (np.abs(v) ** (1.0 / beta) + 1e-8)
    return step

class ImprovedMossGrowthOptimizer:
    """
    Improved Moss Growth Optimization (IMGO) for binary feature selection.
    Features:
    1. Adaptive non-linear moisture inertia weight decay
    2. Levy-flight spore dispersal mechanism for exploration
    3. Elite substrate competition and dynamic neighborhood mutation
    """
    def __init__(self, X, y, feature_names=None, config=IMGO_CONFIG):
        self.X = X
        self.y = y
        self.feature_names = feature_names if feature_names is not None else [f"Feat_{i}" for i in range(X.shape[1])]
        self.num_samples, self.num_features = X.shape
        self.pop_size = config.get("pop_size", 30)
        self.max_iter = config.get("max_iter", 50)
        self.w_max = config.get("w_max", 0.9)
        self.w_min = config.get("w_min", 0.2)
        self.levy_beta = config.get("levy_beta", 1.5)
        self.alpha = config.get("alpha", 0.95)
        self.mutation_rate = config.get("mutation_rate", 0.10)
        self.seed = config.get("seed", RANDOM_SEED)
        
        # Pre-configured stratified CV evaluator for fast & robust fitness calculation
        self.cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=self.seed)

    def evaluate_fitness(self, binary_mask):
        """
        Multi-objective fitness:
        Fitness(X) = alpha * (1 - Acc) + (1 - alpha) * (selected_feats / total_feats)
        """
        selected_indices = np.where(binary_mask == 1)[0]
        if len(selected_indices) == 0:
            return 1.0  # Worst fitness

        X_sub = self.X[:, selected_indices]
        clf = KNeighborsClassifier(n_neighbors=5, weights='distance')
        scores = cross_val_score(clf, X_sub, self.y, cv=self.cv, scoring='accuracy', n_jobs=-1)
        acc = float(np.mean(scores))
        err = 1.0 - acc

        ratio = float(len(selected_indices) / self.num_features)
        fitness = self.alpha * err + (1.0 - self.alpha) * ratio
        return fitness, acc

    def run_optimization(self, standard_mgo=False):
        """
        Runs the optimization loop.
        standard_mgo=True runs the baseline Standard MGO (without Levy flight & adaptive moisture).
        """
        np.random.seed(self.seed)
        
        # Initialize continuous velocities and binary positions
        V = np.random.uniform(-2.0, 2.0, size=(self.pop_size, self.num_features))
        # Initial binary positions (ensure at least 5 features active)
        P = (1.0 / (1.0 + np.exp(-V)) > np.random.uniform(0, 1, size=V.shape)).astype(int)
        for i in range(self.pop_size):
            if np.sum(P[i]) == 0:
                P[i, np.random.choice(self.num_features, size=10, replace=False)] = 1

        fitness_scores = np.zeros(self.pop_size)
        accuracies = np.zeros(self.pop_size)

        for i in range(self.pop_size):
            f, a = self.evaluate_fitness(P[i])
            fitness_scores[i] = f
            accuracies[i] = a

        best_idx = np.argmin(fitness_scores)
        best_pos = P[best_idx].copy()
        best_fitness = fitness_scores[best_idx]
        best_accuracy = accuracies[best_idx]

        convergence_curve = [best_fitness]
        accuracy_curve = [best_accuracy]

        opt_name = "Standard MGO" if standard_mgo else "Proposed IMGO"
        print(f"[Step 7] Running {opt_name} (Pop={self.pop_size}, Iter={self.max_iter}, Feats={self.num_features})...")

        for t in range(1, self.max_iter + 1):
            if standard_mgo:
                # Standard linear decay
                w = self.w_max - (self.w_max - self.w_min) * (t / self.max_iter)
            else:
                # IMGO: Non-linear adaptive moisture decay
                w = self.w_min + (self.w_max - self.w_min) * ((1.0 - (t / self.max_iter)) ** 2)

            for i in range(self.pop_size):
                r1 = np.random.uniform(0, 1, size=self.num_features)
                r2 = np.random.uniform(0, 1, size=self.num_features)

                if standard_mgo:
                    # Standard velocity update
                    V[i] = w * V[i] + 1.5 * r1 * (best_pos - P[i]) + 0.5 * r2 * (np.random.randn(self.num_features))
                else:
                    # IMGO 1: Adaptive moisture + colony attraction
                    c1 = 2.0 * np.exp(- (t / self.max_iter) ** 2)
                    v_attract = c1 * r1 * (best_pos - P[i])
                    
                    # IMGO 2: Levy-Flight Spore Dispersal for top & exploratory colonies
                    if np.random.uniform() < 0.35:
                        step_levy = levy_flight(self.levy_beta, self.num_features)
                        v_spore = 0.05 * step_levy * (P[i] - best_pos)
                    else:
                        v_spore = 0.5 * r2 * np.random.randn(self.num_features)

                    V[i] = w * V[i] + v_attract + v_spore

                # Sigmoid transfer function for binary mapping
                sig_v = 1.0 / (1.0 + np.exp(-np.clip(V[i], -10.0, 10.0)))
                new_pos = (sig_v > np.random.uniform(0, 1, size=self.num_features)).astype(int)

                if not standard_mgo:
                    # IMGO 3: Elite Mutation / Substrate adaptation on stagnant bits
                    mut_mask = np.random.uniform(0, 1, size=self.num_features) < self.mutation_rate
                    new_pos[mut_mask] = 1 - new_pos[mut_mask]

                # Ensure at least 3 features remain selected
                if np.sum(new_pos) < 3:
                    new_pos[np.random.choice(self.num_features, size=5, replace=False)] = 1

                P[i] = new_pos
                f, a = self.evaluate_fitness(P[i])
                fitness_scores[i] = f
                accuracies[i] = a

                if f < best_fitness:
                    best_fitness = f
                    best_accuracy = a
                    best_pos = P[i].copy()

            convergence_curve.append(best_fitness)
            accuracy_curve.append(best_accuracy)

            if t % 10 == 0 or t == self.max_iter:
                sel_count = np.sum(best_pos)
                print(f"  {opt_name} Iter {t:2d}/{self.max_iter:2d} -> Best Fitness: {best_fitness:.4f}, Accuracy: {best_accuracy*100:.2f}%, Selected: {sel_count}/{self.num_features}")

        return {
            "best_mask": best_pos,
            "best_fitness": best_fitness,
            "best_accuracy": best_accuracy,
            "convergence_curve": convergence_curve,
            "accuracy_curve": accuracy_curve,
            "selected_indices": np.where(best_pos == 1)[0]
        }

def run_imgo_feature_selection():
    """
    Executes IMGO feature selection and benchmarks against Standard MGO.
    Saves optimal mask, convergence histories, and selected feature statistics.
    """
    npz_path = PROCESSED_DATA_DIR / "fused_bowing_fingering_features.npz"
    if not npz_path.exists():
        from src.step6_fusion import fuse_bowing_and_fingering_features
        X_fused, y, names = fuse_bowing_and_fingering_features()
    else:
        data = np.load(npz_path)
        X_fused = data['X_fused']
        y = data['y']
        names = list(data['feature_names'])

    optimizer = ImprovedMossGrowthOptimizer(X_fused, y, feature_names=names)
    
    # 1. Run Proposed IMGO
    imgo_res = optimizer.run_optimization(standard_mgo=False)

    # 2. Run Baseline Standard MGO for comparison
    mgo_res = optimizer.run_optimization(standard_mgo=True)

    best_mask = imgo_res['best_mask']
    selected_indices = imgo_res['selected_indices']
    selected_names = [names[i] for i in selected_indices]
    unselected_indices = np.where(best_mask == 0)[0]
    unselected_names = [names[i] for i in unselected_indices]

    num_bow_sel = sum(1 for n in selected_names if "Bowing" in n)
    num_finger_sel = len(selected_names) - num_bow_sel

    print("\n[Step 7] === IMGO Feature Selection Summary ===")
    print(f"Total Original Features: {len(names)}")
    print(f"Total Selected Features: {len(selected_names)} ({len(selected_names)/len(names)*100:.1f}%)")
    print(f"  - Selected Bowing Features: {num_bow_sel} / 32")
    print(f"  - Selected Fingering Features: {num_finger_sel} / 32")
    print(f"Final Validation Accuracy: {imgo_res['best_accuracy']*100:.2f}% (vs MGO: {mgo_res['best_accuracy']*100:.2f}%)")
    print(f"Final Fitness: {imgo_res['best_fitness']:.4f} (vs MGO: {mgo_res['best_fitness']:.4f})")

    # Save results
    out_file = PROCESSED_DATA_DIR / "imgo_selected_features.npz"
    np.savez_compressed(
        out_file,
        X_selected=X_fused[:, selected_indices],
        y=y,
        best_mask=best_mask,
        selected_indices=selected_indices,
        selected_names=np.array(selected_names),
        unselected_names=np.array(unselected_names),
        imgo_convergence=np.array(imgo_res['convergence_curve']),
        imgo_accuracy=np.array(imgo_res['accuracy_curve']),
        mgo_convergence=np.array(mgo_res['convergence_curve']),
        mgo_accuracy=np.array(mgo_res['accuracy_curve']),
        num_bow_sel=num_bow_sel,
        num_finger_sel=num_finger_sel
    )
    print(f"Results saved to {out_file}")
    return imgo_res, mgo_res

if __name__ == "__main__":
    imgo_res, mgo_res = run_imgo_feature_selection()
