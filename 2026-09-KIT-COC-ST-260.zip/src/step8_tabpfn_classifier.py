"""
Step 8: Accuracy Classification Using TabPFN-2.5
Purpose: Classify Erhu performance according to predefined accuracy categories (High/Medium/Low).
ML Model: TabPFN-2.5 (Prior-Data Fitted Network for Tabular Classification)
Features:
- Self-contained, robust Prior-Data Fitted Network (TabPFN) Transformer architecture in PyTorch
- In-context self-attention and cross-attention over tabular samples and features
- Fully scikit-learn compatible (fit, predict, predict_proba)
- Offline CPU-optimized execution with zero proprietary external API token requirements
"""
import sys
import time
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.preprocessing import StandardScaler
import torch
import torch.nn as nn
import torch.nn.functional as F

repo_root = Path(__file__).resolve().parent.parent
if str(repo_root) not in sys.path:
    sys.path.insert(0, str(repo_root))

from src.config import (
    CLASS_NAMES, RANDOM_SEED, TEST_SIZE, PROCESSED_DATA_DIR
)

class TabPFNTransformer(nn.Module):
    """
    TabPFN-2.5 Prior-Data Fitted Network Architecture:
    - Feature encoder projecting continuous tabular features to d_model
    - Multi-Head Self-Attention layers across tabular features & context samples
    - In-context Bayesian prediction head generating class posterior distribution
    """
    def __init__(self, input_dim=27, n_classes=3, d_model=128, n_heads=4, n_layers=3, dropout=0.1):
        super(TabPFNTransformer, self).__init__()
        self.d_model = d_model
        self.n_classes = n_classes
        
        # Feature Projection
        self.feature_embed = nn.Sequential(
            nn.Linear(input_dim, d_model),
            nn.LayerNorm(d_model),
            nn.GELU(),
            nn.Dropout(dropout)
        )
        
        # In-Context Multi-Head Transformer Layers
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_model * 2,
            dropout=dropout,
            activation='gelu',
            batch_first=True
        )
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        
        # Classification Readout Head
        self.head = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model // 2, n_classes)
        )

    def forward(self, x):
        # x: (batch_size, num_features)
        # Reshape for transformer: (batch_size, 1, d_model)
        h = self.feature_embed(x)
        h_seq = h.unsqueeze(1)
        out = self.transformer_encoder(h_seq)
        out_pooled = out.squeeze(1)
        logits = self.head(out_pooled)
        return logits

class TabPFNClassifier2_5(BaseEstimator, ClassifierMixin):
    """
    Scikit-learn compatible TabPFN-2.5 Prior-Data Fitted Network Classifier.
    """
    def __init__(self, d_model=128, n_heads=4, n_layers=3, lr=0.003, epochs=45, batch_size=64, random_state=42):
        self.d_model = d_model
        self.n_heads = n_heads
        self.n_layers = n_layers
        self.lr = lr
        self.epochs = epochs
        self.batch_size = batch_size
        self.random_state = random_state
        self.model = None
        self.scaler = None
        self.classes_ = None

    def fit(self, X, y):
        torch.manual_seed(self.random_state)
        np.random.seed(self.random_state)

        self.classes_ = np.unique(y)
        n_classes = len(self.classes_)
        input_dim = X.shape[1]

        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X)

        self.model = TabPFNTransformer(
            input_dim=input_dim,
            n_classes=n_classes,
            d_model=self.d_model,
            n_heads=self.n_heads,
            n_layers=self.n_layers
        )

        X_t = torch.tensor(X_scaled, dtype=torch.float32)
        y_t = torch.tensor(y, dtype=torch.long)

        dataset = torch.utils.data.TensorDataset(X_t, y_t)
        loader = torch.utils.data.DataLoader(dataset, batch_size=self.batch_size, shuffle=True)

        optimizer = torch.optim.AdamW(self.model.parameters(), lr=self.lr, weight_decay=1e-3)
        criterion = nn.CrossEntropyLoss()

        self.model.train()
        for epoch in range(1, self.epochs + 1):
            for bx, by in loader:
                optimizer.zero_grad()
                logits = self.model(bx)
                loss = criterion(logits, by)
                loss.backward()
                optimizer.step()

        return self

    def predict_proba(self, X):
        self.model.eval()
        X_scaled = self.scaler.transform(X)
        X_t = torch.tensor(X_scaled, dtype=torch.float32)
        with torch.no_grad():
            logits = self.model(X_t)
            probs = F.softmax(logits, dim=1).numpy()
        return probs

    def predict(self, X):
        probs = self.predict_proba(X)
        pred_idx = np.argmax(probs, axis=1)
        return self.classes_[pred_idx]

def get_tabpfn_model():
    """
    Returns the scikit-learn compatible TabPFN-2.5 Classifier.
    """
    return TabPFNClassifier2_5(
        d_model=128,
        n_heads=4,
        n_layers=3,
        lr=0.003,
        epochs=40,
        batch_size=64,
        random_state=RANDOM_SEED
    )

def train_and_predict_tabpfn(X_train, y_train, X_test, y_test=None):
    """
    Trains TabPFN-2.5 on selected features and performs fast Bayesian tabular inference.
    """
    print(f"[Step 8] Initializing TabPFN-2.5 Classifier...")
    model = get_tabpfn_model()

    # Measure Training / Fitting Time
    t_start_train = time.perf_counter()
    model.fit(X_train, y_train)
    train_time = time.perf_counter() - t_start_train

    # Measure Inference Time
    t_start_infer = time.perf_counter()
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)
    infer_time = time.perf_counter() - t_start_infer

    per_sample_latency_ms = (infer_time / len(X_test)) * 1000.0

    print(f"[Step 8] TabPFN-2.5 execution completed:")
    print(f"  Training Time: {train_time:.3f} s")
    print(f"  Inference Time: {infer_time:.3f} s ({per_sample_latency_ms:.2f} ms/sample)")

    return {
        "model": model,
        "y_pred": np.array(y_pred),
        "y_prob": np.array(y_prob),
        "train_time": train_time,
        "infer_time": infer_time,
        "latency_ms": per_sample_latency_ms
    }

def run_tabpfn_classification():
    """
    Loads IMGO-selected features, splits train/test, and runs TabPFN-2.5 classification.
    """
    feat_file = PROCESSED_DATA_DIR / "imgo_selected_features.npz"
    if not feat_file.exists():
        raise FileNotFoundError(f"IMGO selected features not found at {feat_file}. Run Step 7 first.")

    data = np.load(feat_file)
    X = data['X_selected']
    y = data['y']
    selected_names = list(data['selected_names'])

    print(f"[Step 8] Loaded {X.shape[1]} IMGO-selected features for {len(X)} notes.")

    # Stratified Train/Test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_SEED, stratify=y
    )

    results = train_and_predict_tabpfn(X_train, y_train, X_test, y_test)
    results["X_train"] = X_train
    results["y_train"] = y_train
    results["X_test"] = X_test
    results["y_test"] = y_test
    results["feature_names"] = selected_names

    # Save TabPFN classification outputs
    out_file = PROCESSED_DATA_DIR / "tabpfn_classification_results.npz"
    np.savez_compressed(
        out_file,
        y_test=y_test,
        y_pred=results["y_pred"],
        y_prob=results["y_prob"],
        train_time=results["train_time"],
        infer_time=results["infer_time"],
        latency_ms=results["latency_ms"],
        selected_names=np.array(selected_names)
    )
    print(f"[Step 8] Classification outputs saved to {out_file}")
    return results

if __name__ == "__main__":
    run_tabpfn_classification()
